#!/bin/bash

# Verificar quais IP's est�o com o hor�rio coreto ou errado
#for IP in $(cat teste_ip.txt); do echo $IP; sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP date; done | tee >> log

for IP in $(cat teste_ip.txt);

do

echo $IP;

# Acertar Hor�rio dos respectivos IP's indicados em "teste_ip.txt"
sshpass -p zanthus scp -oStrictHostKeyChecking=no Sao_Paulo root@$IP:/usr/share/zoneinfo/America/ >> log.txt 1>erros.txt;
sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP dpkg-reconfigure -f noninteractive tzdata;
sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP date "+%Z%z";




done

#tar -zcvf TimeZoneLubuntu12.tgz /usr/share/zoneinfo/America/Sao_Paulo /usr/share/zoneinfo/Brazil/East /usr/share/zoneinfo/Brazil/West /etc/localtime /etc/adjtime
