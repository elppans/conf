#!/bin/bash

##	OPCIONAL

# Adicionar na última linha do arquivo o seguinte parâmetro (Descomentado):

# 00 0    * * *   root /Zanthus/Zeus/path_comum/MudancaTimeZone/exec_00h.sh

cd /Zanthus/Zeus/path_comum/MudancaTimeZone
chmod +x mudar_hora.sh
./mudar_hora.sh
