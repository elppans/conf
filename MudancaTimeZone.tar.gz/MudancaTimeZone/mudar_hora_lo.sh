#!/bin/bash

# No CentOS n�o existe o domando dpkg-*, por�m, o hor�rio � modificado normalmente

echo "Horario atual..."
date "+%Z (%z)"
date
unlink /usr/share/zoneinfo/America/Sao_Paulo
cp -rfv Sao_Paulo /usr/share/zoneinfo/America/
dpkg-reconfigure -f noninteractive tzdata
hwclock -w
echo "Horario apos mudanca..."
date "+%Z (%z)"
date