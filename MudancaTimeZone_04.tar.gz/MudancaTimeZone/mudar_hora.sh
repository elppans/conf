#!/bin/bash

##		(OPCIONAL) IP servidor de hor�rio local (OPCIONAL)
#	Para usar, descomente a linha sshpass comentada e troque o IP mencionado na vari�vel "NT" pelo IP de prefer~encia e com hor�rio correto


NT=192.168.10.254

##	Verificar "sshpass"
if (  whereis sshpass | grep bin )  >> /dev/null ; then
        echo "sshpass ok..."
  else
if ( whereis apt-get | grep bin ); then
        echo "apt-get OK..."
	apt-get -y install sshpass
  else
if ( ! whereis apt-get | grep bin ); then
        echo "Não foi possivel instalar a dependência..."
fi
fi
fi

if (  whereis sshpass | grep bin )  >> /dev/null ; then
        echo "sshpass ok..."
  else
if ( whereis yum | grep bin ); then
        echo "yum OK..."
        yum -y install sshpass
  else
if ( ! whereis yum | grep bin ); then
        echo "Não foi possivel instalar a dependência..."
fi
fi
fi
##	Verificar "sshpass" FIM

for IP in $(cat teste_ip.txt);

do

echo $IP;

## Acertar Hor�rio dos respectivos IP's indicados em "teste_ip.txt"
sshpass -p zanthus scp -oStrictHostKeyChecking=no Sao_Paulo root@$IP:/usr/share/zoneinfo/America/ >> log.txt 1>erros.txt;
sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP dpkg-reconfigure -f noninteractive tzdata;

# sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP net time set -I "$NT";

sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP hwclock -w;
sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP date "+%c%z";




done

#tar -zcvf TimeZoneLubuntu12.tgz /usr/share/zoneinfo/America/Sao_Paulo /usr/share/zoneinfo/Brazil/East /usr/share/zoneinfo/Brazil/West /etc/localtime /etc/adjtime
