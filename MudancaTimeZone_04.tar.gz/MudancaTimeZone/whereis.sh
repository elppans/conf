#!/bin/bash

if ( whereis apt-get | grep bin ); then
	echo "apt-get OK..."
  else
	echo "apt-get ELSE!"
fi

if ( whereis yum | grep bin ); then
	echo "yum OK..."
  else
	echo "yum ELSE!"
fi
