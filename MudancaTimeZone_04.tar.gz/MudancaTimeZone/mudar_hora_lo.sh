#!/bin/bash

date "+%Z (%z)"
date
unlink /usr/share/zoneinfo/America/Sao_Paulo
cp -rfv Sao_Paulo /usr/share/zoneinfo/America/
dpkg-reconfigure -f noninteractive tzdata
hwclock -w
date "+%Z (%z)"
date