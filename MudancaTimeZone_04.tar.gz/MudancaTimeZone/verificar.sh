#!/bin/bash

##	Verificar "sshpass"
if (  whereis sshpass | grep bin )  >> /dev/null ; then
        echo "sshpass ok..."
  else
if ( whereis apt-get | grep bin ); then
        echo "apt-get OK..."
	apt-get -y install sshpass
  else
if ( ! whereis apt-get | grep bin ); then
        echo "Não foi possivel instalar a dependência..."
fi
fi
fi

if (  whereis sshpass | grep bin )  >> /dev/null ; then
        echo "sshpass ok..."
  else
if ( whereis yum | grep bin ); then
        echo "yum OK..."
        yum -y install sshpass
  else
if ( ! whereis yum | grep bin ); then
        echo "Não foi possivel instalar a dependência..."
fi
fi
fi
##	Verificar "sshpass" FIM

for IP in $(cat teste_ip.txt);

do

echo $IP;

# Verificar Horário dos respectivos IP's indicados em "teste_ip.txt"
sshpass -p zanthus ssh -oStrictHostKeyChecking=no $IP date +%c%z ;

done



