#!/bin/bash

# Verificar quais IP's est�o com o hor�rio coreto ou errado
for IP in $(cat teste_ip.txt);
do

echo $IP;
ssh-keygen -R $IP;

done | tee >> log